﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TSMECS
{
    public static class LocalLog
    {
        public static void writeLog(string msg)
        {
            //string path = System.IO.Directory.GetCurrentDirectory() + @"\log.txt";
            //FileStream f = new FileStream(path, FileMode.Append);
            //StreamWriter w = new StreamWriter(f);
            //w.WriteLine(msg);
            //w.Flush();
            //w.Close();
        }
    }
}
